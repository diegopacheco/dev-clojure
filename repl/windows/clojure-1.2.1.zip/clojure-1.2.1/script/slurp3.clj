(time (slurp "words"))
