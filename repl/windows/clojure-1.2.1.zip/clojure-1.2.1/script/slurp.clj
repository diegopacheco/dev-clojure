(time (slurp System/in))
